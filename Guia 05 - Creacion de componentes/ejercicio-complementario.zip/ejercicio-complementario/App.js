/**
 * @format
 * @flow strict-local
 */
import React, {useState, useEffect} from 'react';
import {
 SafeAreaView,
 StyleSheet,
 View,
 Text,
 StatusBar,
} from 'react-native';
import colors from './src/utils/colors';
import Form from './src/components/Form';
import Footer from './src/components/Footer';
import Result from './src/components/Result';

export default function App(){
  const[name, setName] = useState('');
  const[salario, setSalario] = useState(null);
  const[total,setTotal] = useState(null);
  const[errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if(name && salario) calculate();
    else reset();
  },[name,salario]);

  const calculate =() =>{
    reset();
    if (!name) {
 setErrorMessage('Añade el nombre del usuario');
 } else if (!salario) {
 setErrorMessage('Añade el interes del prestamos');
 } else {
 const descISSS = salario*(0.03);
 const descAFP = salario*(0.04);
 const descRenta = salario*(0.05);
 const fee = salario - (descISSS + descAFP + descRenta);
 setTotal({
 totalPayable: (fee).toFixed(2).replace('.', ','),
 });
 }
 };

const reset = () =>{
  setErrorMessage('');
  setTotal(null);
};
  
return(
 <>
 <StatusBar barStyle="light-content"/>
 <SafeAreaView style={styles.Header}>
 <Text style={styles.TextPrincipal}>Calculador de Salario Neto</Text>
 </SafeAreaView>
 <View style={styles.Content}>
 <Form
 setName={setName}
 setSalario={setSalario}
 />
 </View>
 <Result
 name={name}
 salario={salario}
 total={total}
 errorMessage={errorMessage}
 />
 <View>
 <Footer calculate={calculate} />
 </View>
 </>
);
}
const styles = StyleSheet.create({
 Header:{
 backgroundColor:colors.PRIMARY_COLOR,
 height:120,
 borderBottomLeftRadius:0,
 borderBottomRightRadius:0,
alignItems:'center'
 },
TextPrincipal:{
  fontSize:20,
  fontWeight:'bold',
  color: 'black',
  marginTop:50
},
Content:{
  height:140,
  backgroundColor:colors.SECUNDARY_COLOR,
},
})
