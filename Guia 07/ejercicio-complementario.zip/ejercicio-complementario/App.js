import React, { useState } from 'react';
import {
  View,
  StyleSheet,
  Image,
  Text,
  ScrollView,
  Modal,
  Button,
  TouchableHighlight,
} from 'react-native';
const App = () => {
  const [modalVisibleDeluxe, setModalVisibleDeluxe] = useState(false);
  const [modalVisiblePremium, setModalVisiblePremium] = useState(false);
  const [modalVisibleGold, setModalVisibleGold] = useState(false);
  const [modalVisibleClassic, setModalVisibleClassic] = useState(false);
  const [modalVisibleStandard, setModalVisibleStandard] = useState(false);

  const [modalVisiblePlatos, setModalVisiblePlatos] = useState(false);
  const [modalVisiblePiscina, setModalVisiblePiscina] = useState(false);
  const [modalVisibleBar, setModalVisibleBar] = useState(false);

  const [modalVisibleRuta, setModalVisibleRuta] = useState(false);
  return (
    <>
      <ScrollView>
        <Modal
          transparent={true}
          animationType="slide"
          visible={modalVisibleDeluxe}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={styles.visitaModal}>
            <View style={styles.Modal}>
              <Text style={styles.subtitulo}>Habitacion Deluxe</Text>
              <Text>-----------------------</Text>
              <Text>
                Habitación de mas alto rango en nuestras instalaciones contando con una cama King, comedor, duchas privadas, sala de estar,
                balcon, mostrador de vinos y camara de masajes.
              </Text>
              <Button
                title="Cerrar"
                onPress={() => {
                  setModalVisibleDeluxe(!modalVisibleDeluxe);
                }} ></Button>
            </View>
          </View>
        </Modal>

        <Modal
          transparent={true}
          animationType="slide"
          visible={modalVisiblePremium}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={styles.visitaModal}>
            <View style={styles.Modal}>
              <Text style={styles.subtitulo}>Habitacion Premium</Text>
              <Text>-----------------------</Text>
              <Text>
                Habitación que ofrece comodidades a nuestros huespedes contando con una cama Queen, escritorio amplio, sala de estar, ducha
                privada, balcon y mostrador de vinos.
              </Text>
              <Button
                title="Cerrar"
                onPress={() => {
                  setModalVisiblePremium(!modalVisiblePremium);
                }} ></Button>
            </View>
          </View>
        </Modal>

        <Modal
          transparent={true}
          animationType="slide"
          visible={modalVisibleGold}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={styles.visitaModal}>
            <View style={styles.Modal}>
              <Text style={styles.subtitulo}>Habitacion Gold</Text>
              <Text>---------------------</Text>
              <Text>
                Habitación con altos estandares de tranquilidad y confort contando con una cama Queen, escritorio personal, silla de relajación,
                balcon con vista a la ciudad y una ducha privada.

              </Text>
              <Button
                title="Cerrar"
                onPress={() => {
                  setModalVisibleGold(!modalVisibleGold);
                }} ></Button>
            </View>
          </View>
        </Modal>

        <Modal
          transparent={true}
          animationType="slide"
          visible={modalVisibleClassic}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={styles.visitaModal}>
            <View style={styles.Modal}>
              <Text style={styles.subtitulo}>Habitacion Classic</Text>
              <Text>-----------------------</Text>
              <Text>
                Habitación accesible para cualquier huesped que desea disfrutar de todo lo que el hotel dispone para ellos contando con una cama
                tamaño Full, ducha privada, vistas a la ciudad y escritorio personal.
              </Text>
              <Button
                title="Cerrar"
                onPress={() => {
                  setModalVisibleClassic(!modalVisibleClassic);
                }} ></Button>
            </View>
          </View>
        </Modal>

        <Modal
          transparent={true}
          animationType="slide"
          visible={modalVisibleStandard}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={styles.visitaModal}>
            <View style={styles.Modal}>
              <Text style={styles.subtitulo}>Habitacion Standard</Text>
              <Text>-----------------------</Text>
              <Text>
                Habitación comoda que le hará pasar una buena noche de hospedaje en el hotel, cuenta con una cama tamaño Twin, mesa pequeña
                y una ducha privada (habitación disponible solo para uso de una noche).
              </Text>
              <Button
                title="Cerrar"
                onPress={() => {
                  setModalVisibleStandard(!modalVisibleStandard);
                }} ></Button>
            </View>
          </View>
        </Modal>



        <Modal
          transparent={true}
          animationType="slide"
          visible={modalVisiblePlatos}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={styles.Modal}>
              <Text style={styles.subtitulo}>Platillos hasta la puerta de tu habitación</Text>
              <Text>-------------------------------------</Text>
              <Text>
                Servicio de solicitud y entrega de desayuno, almuerzos y cenas hasta la puerta de tu habitación con los productos de mas alta
                frescura y un servicio eficaz ( Servicio solo disponible para habitaciones de tipo Deluxe, Premium y Gold )
              </Text>
              <Button
                title="Cerrar"
                onPress={() => {
                  setModalVisiblePlatos(!modalVisiblePlatos);
                }} ></Button>
          </View>
        </Modal>

        <Modal
          transparent={true}
          animationType="slide"
          visible={modalVisiblePiscina}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={styles.Modal}>
              <Text style={styles.subtitulo}>Piscinas termales</Text>
              <Text>-------------------------------------</Text>
              <Text>
                Prueba nuestras piscinas termales con una agua higienica para el uso de todas las edades a cualquier hora del día 
                ( Servicio solo disponible para habitaciones de tipo Deluxe, Premium, Gold y Classic )
              </Text>
              <Button
                title="Cerrar"
                onPress={() => {
                  setModalVisiblePiscina(!modalVisiblePiscina);
                }} ></Button>
          </View>
        </Modal>

        <Modal
          transparent={true}
          animationType="slide"
          visible={modalVisibleBar}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={styles.Modal}>
              <Text style={styles.subtitulo}>Bar y Karaoke</Text>
              <Text>-------------------------------------</Text>
              <Text>
                Disfuta de un momento con tus amigos y pareja en nuestro Bar y Karaoke dispuesto a ofrecerte un momento de diversión contando
                con una diversidad de pistas musicales y servicio de comida y bebidas a tu gusto ( Servicio solo disponible para habitaciones
                de tipo Deluxe, Premium y Gold )
              </Text>
              <Button
                title="Cerrar"
                onPress={() => {
                  setModalVisibleBar(!modalVisibleBar);
                }} ></Button>
          </View>
        </Modal>



        <Modal
          transparent={true}
          animationType="slide"
          visible={modalVisibleRuta}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={styles.Modal}>
              <Text style={styles.subtitulo}>
              Visita atracciones cercanas al hotel</Text>
              <Text>
                Puedes disfrutar de muchos lugares cercanos al hotel en lo que dure tu estancia en este.
              </Text>
              <Button
                title="Cerrar"
                onPress={() => {
                  setModalVisibleRuta(!modalVisibleRuta);
                }} ></Button>
          </View>
        </Modal>
        



        <View>
        <Text style={styles.tituloresort}>Magical Hotel</Text>
        </View>

        <View style={{ flexDirection: 'row' }}>
          
          <Image style={styles.banner} source={require('./src/img/bg.jpg')} />
        </View>

        <View style={styles.contenedor}>
          <Text style={styles.titulo}>Habitaciones disponibles</Text>

          <ScrollView horizontal>
            <View>
              <TouchableHighlight
                onPress={() => {
                  setModalVisibleDeluxe(!modalVisibleDeluxe);
                }}>
                <Image
                  style={styles.ciudad}
                  source={require('./src/img/Deluxe.jpg')}
                />
              </TouchableHighlight>
            </View>

            <View>
            <TouchableHighlight
                onPress={() => {
                  setModalVisiblePremium(!modalVisiblePremium);
                }}>
              <Image
                style={styles.ciudad}
                source={require('./src/img/Premium.jpg')}
              />
              </TouchableHighlight>
            </View>

            <View>
             <TouchableHighlight
                onPress={() => {
                  setModalVisibleGold(!modalVisibleGold);
                }}>
              <Image
                style={styles.ciudad}
                source={require('./src/img/Gold.jpg')}
              />
              </TouchableHighlight>
            </View>

            <View>
            <TouchableHighlight
                onPress={() => {
                  setModalVisibleClassic(!modalVisibleClassic);
                }}>
              <Image
                style={styles.ciudad}
                source={require('./src/img/Classic.jpg')}
              />
              </TouchableHighlight>
            </View>

            <View>
            <TouchableHighlight
                onPress={() => {
                  setModalVisibleStandard(!modalVisibleStandard);
                }}>
              <Image
                style={styles.ciudad}
                source={require('./src/img/Standard.jpg')}
              />
              </TouchableHighlight>
            </View>
          </ScrollView>

          <Text style={styles.titulo}>Servicios para nuestros huespedes</Text>

          <View>

            <View>
            <TouchableHighlight
                onPress={() => {
                  setModalVisiblePlatos(!modalVisiblePlatos);
                }}>
              <Image
                style={styles.mejores}
                source={require('./src/img/comida.jpg')}
              />
              </TouchableHighlight>
            </View>

            <View>
            <TouchableHighlight
                onPress={() => {
                  setModalVisiblePiscina(!modalVisiblePiscina);
                }}>
              <Image
                style={styles.mejores}
                source={require('./src/img/piscina.jpg')}
              />
              </TouchableHighlight>
            </View>
            <View>
            <TouchableHighlight
                onPress={() => {
                  setModalVisibleBar(!modalVisibleBar);
                }}>
              <Image
                style={styles.mejores}
                source={require('./src/img/bar.jpg')}
              />
              </TouchableHighlight>
            </View>
          </View>

          <Text style={styles.titulo}>Lugares de interes cercanos</Text>
          <View style={styles.listado}>
            
            <View style={styles.listaItem}>
            <TouchableHighlight 
            onPress={() => {
              setModalVisibleRuta(!modalVisibleRuta)
            }}>
              <Image
                style={styles.mejores}
                source={require('./src/img/lugar1.jpg')}
              />
              </TouchableHighlight>
            </View>

            <View style={styles.listaItem}>
              <Image
                style={styles.mejores}
                source={require('./src/img/lugar2.jpg')}
              />
            </View>

            <View style={styles.listaItem}>
              <Image
                style={styles.mejores}
                source={require('./src/img/lugar3.jpg')}
              />
            </View>

            <View style={styles.listaItem}>
              <Image
                style={styles.mejores}
                source={require('./src/img/lugar4.jpg')}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </>
  );
};
const styles = StyleSheet.create({
  banner: {
    height: 250,
    flex: 1,
  },
  titulo: {
    fontWeight: 'bold',
    fontSize: 24,
    marginVertical: 10,
  },
  tituloresort: {
    color:'white',
    fontWeight: 'bold',
    fontSize: 24,
    marginVertical: 10,
    paddingHorizontal:'27%',
    paddingBottom:'5%',
    paddingTop:'5%',
    backgroundColor:'blue'
  },
  contenedor: {
    marginHorizontal: 10,
  },
  ciudad: {
    width: 250,
    height: 300,
    marginRight: 10,
  },
  mejores: {
    width: '100%',
    height: 200,
    marginVertical: 5,
  },
  listaItem: {
    flexBasis: '49%',
  },
  listado: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  visitaModal: {
    backgroundColor: '#000000aa',
    flex: 1,
  },
  Modal: {
    backgroundColor: '#fff',
    margin: 50,
    padding: 40,
    borderRadius: 10,
    flex: 1,
  },
  subtitulo: {
    fontWeight: 'bold',
    fontSize: 14,
    justifyContent: 'center',
  },
});

export default App;

