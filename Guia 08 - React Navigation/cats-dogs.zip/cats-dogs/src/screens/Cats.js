import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
export default function About() {
  return (
      <View style={{flexDirection:'column'}}>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/Orange.png')}/>
        <Text style={{padding:'20px'}}><b>Orange Tabby</b></Text>
        <Text style={{padding:'20px'}}>Inglaterra</Text>
        </View>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/caracal.png')}/>
        <Text style={{padding:'20px'}}><b>Caracal</b></Text>
        <Text style={{padding:'20px'}}>Africa</Text>
        </View>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/Maine.png')}/>
        <Text style={{padding:'20px'}}><b>Maine Coon</b></Text>
        <Text style={{padding:'20px'}}>Estados Unidos</Text>
        </View>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/Persa.png')}/>
        <Text style={{padding:'20px'}}><b>Persa</b></Text>
        <Text style={{padding:'20px'}}>Iran</Text>
        </View>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/Siberiano.png')}/>
        <Text style={{padding:'20px'}}><b>Siberiano</b></Text>
        <Text style={{padding:'20px'}}>Rusia</Text>
        </View>
        
      </View>
  );
}