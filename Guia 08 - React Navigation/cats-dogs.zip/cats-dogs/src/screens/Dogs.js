import React from 'react';
import { View, Text, Button, StyleSheet, Image } from 'react-native';
export default function Home(props) {
  const { navigation } = props;
  return (
      <View style={{flexDirection:'column', flex:'1'}}>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/Pastor.png')}/>
        <Text style={{padding:'20px'}}><b>Pastor Aleman</b></Text>
        <Text style={{padding:'20px'}}>Alemania</Text>
        </View>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/French.png')}/>
        <Text style={{padding:'20px'}}><b>French Maltes</b></Text>
        <Text style={{padding:'20px'}}>Sicilia</Text>
        </View>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/Danes.png')}/>
        <Text style={{padding:'20px'}}><b>Gran Danés</b></Text>
        <Text style={{padding:'20px'}}>Alemania</Text>
        </View>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/bulldog.png')}/>
        <Text style={{padding:'20px'}}><b>Bulldog</b></Text>
        <Text style={{padding:'20px'}}>Reino Unido</Text>
        </View>

        <View style={{flexDirection:'row', paddingBottom:'10px'}}>
        <Image style={{width:'100px', height:'100px'}} source={require('../images/Labrador.png')}/>
        <Text style={{padding:'20px'}}><b>Labrador</b></Text>
        <Text style={{padding:'20px'}}>Isla de Terranova</Text>
        </View>
        
      </View>
  )
  
}